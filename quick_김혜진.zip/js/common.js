$(function(){
  const dTop = parseInt($("#quick_menu").css("top"));
  $(window).on("scroll",function(){
    const scv = $(window).scrollTop();   /* scrollTop : 스크롤했을때 거리 */
    $("#quick_menu").stop().animate({top:scv+dTop+"px"},1000);    /* 스크롤했을 때 div박스를 top을 저만큼 움직여라 */
  })


$("#quick_menu ul a").click(function(e){
  $.scrollTo(this.hash||0,1500);
  e.preventDefault();
});
});
