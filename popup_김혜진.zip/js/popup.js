$(function(){
  if($.cookie("pop") != "no") $(".pop_wrap").show();    /* 하루동안 보이지 않은 상태이기 때문... */
  $(".pop_wrap").css("cursor","move").draggable();  /* draggable하면 -> 플러그인에 따라 움직여짐~~(jquery-ui..이거~) */
  $(".pop_wrap area:eq(0)").on("click",function(){
    $(".pop_wrap").fadeOut("fast");
  });

$(".pop_wrap area:eq(1)").on("click", function(){
  $.cookie("pop", "no", {expires:1});      //하루동안 표시않기를 누르면 --> no라고 설정!!!
                                         //그리고 expires, 즉 기한을 1일로 둔다. (1일동안 안보임)
  $(".pop_wrap").fadeOut("fast");
});



});
